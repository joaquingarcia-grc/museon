DROP TABLE IF EXISTS `atributos`;
CREATE TABLE `atributos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `denominacion` varchar(100) NOT NULL,
  `tipo_dato` varchar(20) NOT NULL,
  `unidad` varchar(20) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT current_timestamp(),
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_edicion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `atributos` VALUES ('1', 'altura', 'texto', NULL, '2026-08-18 12:02:47', '2026-09-17 13:35:15', '2026-09-17 13:35:15');
INSERT INTO `atributos` VALUES ('2', 'dia de gracias', 'fecha', NULL, '2026-08-18 12:04:09', '2026-09-14 21:51:06', '2026-09-14 21:51:06');
INSERT INTO `atributos` VALUES ('3', '', '', NULL, '2026-08-18 12:12:23', NULL, '2026-09-15 23:22:38');
INSERT INTO `atributos` VALUES ('4', 'peso', 'numerico', NULL, '2026-08-21 21:37:16', '2026-09-14 21:52:13', '2026-09-14 21:52:13');
INSERT INTO `atributos` VALUES ('5', 'dia de mañana', 'fecha', NULL, '2026-08-24 22:54:20', NULL, '2026-09-14 23:33:47');
INSERT INTO `atributos` VALUES ('6', 'peso plumita', 'numerico', NULL, '2026-08-24 23:26:20', NULL, '2026-09-17 11:39:00');
INSERT INTO `atributos` VALUES ('7', 'texto', 'texto', NULL, '2026-09-04 14:17:59', NULL, '2026-09-15 23:19:54');
INSERT INTO `atributos` VALUES ('8', 'luis', 'texto', NULL, '2026-09-04 14:18:18', NULL, '2026-09-15 23:18:37');
INSERT INTO `atributos` VALUES ('9', 'juanp', 'texto', NULL, '2026-09-04 14:24:50', NULL, '2026-09-15 23:18:28');
INSERT INTO `atributos` VALUES ('10', 'pergolini', 'texto', NULL, '2026-09-04 14:34:24', NULL, '2026-09-15 23:29:16');
INSERT INTO `atributos` VALUES ('11', 'pitagorico', 'numerico', NULL, '2026-09-04 21:21:51', NULL, '2026-09-11 13:58:24');
INSERT INTO `atributos` VALUES ('12', 'leon', 'texto', NULL, '2026-09-04 21:25:48', '2026-09-07 23:52:07', '2026-09-07 23:52:07');
INSERT INTO `atributos` VALUES ('13', 'diametro', 'numerico', NULL, '2026-09-04 21:55:49', '2026-09-07 23:53:01', '2026-09-07 23:53:01');
INSERT INTO `atributos` VALUES ('14', 'ingredientes', 'texto', NULL, '2026-09-04 21:57:44', '2026-09-07 23:56:23', '2026-09-07 23:56:23');
INSERT INTO `atributos` VALUES ('15', 'padu', 'texto', NULL, '2026-09-07 11:53:43', '2026-09-07 23:56:42', '2026-09-07 23:56:42');
INSERT INTO `atributos` VALUES ('16', 'laravel', 'texto', NULL, '2026-09-07 12:08:18', '2026-09-08 02:33:05', '2026-09-08 02:33:05');
INSERT INTO `atributos` VALUES ('17', 'hy6y', 'texto', NULL, '2026-09-07 21:54:36', '2026-09-08 02:55:41', '2026-09-08 02:55:41');
INSERT INTO `atributos` VALUES ('18', 'maida', 'texto', NULL, '2026-09-08 12:52:31', '2026-09-10 12:45:28', '2026-09-10 12:45:28');
INSERT INTO `atributos` VALUES ('19', 'ancho', 'fecha', NULL, '2026-09-08 14:23:12', NULL, '2026-09-11 12:29:02');
INSERT INTO `atributos` VALUES ('20', 'perro', 'numerico', NULL, '2026-09-09 13:48:34', '2026-09-11 11:33:38', '2026-09-11 11:33:38');
INSERT INTO `atributos` VALUES ('21', 'juan', 'texto', NULL, '2026-09-09 13:55:08', '2026-09-11 11:35:19', '2026-09-11 11:35:19');
INSERT INTO `atributos` VALUES ('22', 'etor', 'texto', NULL, '2026-09-09 13:56:54', '2026-09-11 11:35:26', '2026-09-11 11:35:26');
INSERT INTO `atributos` VALUES ('23', 'dicemetro', 'numerico', NULL, '2026-09-09 13:59:53', '2026-09-11 11:35:35', '2026-09-11 11:35:35');
INSERT INTO `atributos` VALUES ('24', 'lushi', 'numerico', NULL, '2026-09-09 14:01:15', '2026-09-11 11:35:43', '2026-09-11 11:35:43');
INSERT INTO `atributos` VALUES ('25', 'g', 'numerico', NULL, '2026-09-09 14:01:30', NULL, '2026-10-19 22:39:24');
INSERT INTO `atributos` VALUES ('26', 'pesos', 'numerico', NULL, '2026-09-09 14:02:36', NULL, '2026-10-19 22:39:24');
INSERT INTO `atributos` VALUES ('27', 'etores', 'numerico', NULL, '2026-09-09 14:03:47', NULL, '2026-10-19 22:39:23');
INSERT INTO `atributos` VALUES ('28', 'gari', 'archivo', NULL, '2026-09-09 14:04:41', NULL, '2026-09-09 14:04:41');
INSERT INTO `atributos` VALUES ('29', 'dimencion x', 'numerico', NULL, '2026-09-09 14:13:12', NULL, '2026-09-09 14:13:12');
INSERT INTO `atributos` VALUES ('30', 'dimencion y', 'numerico', NULL, '2026-09-09 14:14:14', NULL, '2026-09-09 14:14:14');
INSERT INTO `atributos` VALUES ('31', 'dimencion z', 'numerico', NULL, '2026-09-09 14:14:41', NULL, '2026-10-19 22:39:22');
INSERT INTO `atributos` VALUES ('32', 'pesetas', 'numerico', NULL, '2026-09-09 14:18:23', NULL, '2026-10-19 22:39:20');
INSERT INTO `atributos` VALUES ('33', 'pesitos', 'numerico', NULL, '2026-09-09 14:19:00', NULL, '2026-10-19 22:39:19');
INSERT INTO `atributos` VALUES ('34', 'juanpes', 'texto', NULL, '2026-09-09 14:23:28', NULL, '2026-10-19 22:39:18');
INSERT INTO `atributos` VALUES ('35', 'perreques', 'texto', NULL, '2026-09-09 14:23:50', NULL, '2026-10-19 22:39:17');
INSERT INTO `atributos` VALUES ('36', 'larivel', 'texto', NULL, '2026-09-10 11:02:53', '2026-09-25 11:59:43', '2026-09-25 11:59:43');
INSERT INTO `atributos` VALUES ('37', 'gnora', 'texto', NULL, '2026-09-10 11:07:14', NULL, '2026-09-28 13:18:02');
INSERT INTO `atributos` VALUES ('38', 'retar', 'numerico', NULL, '2026-09-10 11:17:54', NULL, '2026-09-28 13:16:48');
INSERT INTO `atributos` VALUES ('39', 'kasdlkajsd', 'texto', NULL, '2026-09-10 11:18:53', NULL, '2026-10-19 22:39:16');
INSERT INTO `atributos` VALUES ('40', 'holis', 'texto', NULL, '2026-09-10 11:19:29', NULL, '2026-09-28 13:16:46');
INSERT INTO `atributos` VALUES ('41', 'pesetotes', 'numerico', NULL, '2026-09-10 11:20:07', NULL, '2026-10-19 22:39:15');
INSERT INTO `atributos` VALUES ('42', 'lksajldkjaslkdjlkasjdlkas', 'numerico', NULL, '2026-09-10 11:20:31', NULL, '2026-09-28 13:16:45');
INSERT INTO `atributos` VALUES ('43', 'sdfghjklasdfghjklwertyuiocvbnm', 'numerico', NULL, '2026-09-10 11:20:56', NULL, '2026-10-19 22:39:14');
INSERT INTO `atributos` VALUES ('44', 'Color', 'texto', NULL, '2026-09-11 09:35:03', '2026-09-22 11:25:44', '2026-09-22 11:25:44');
INSERT INTO `atributos` VALUES ('45', 'Color', 'texto', NULL, '2026-09-11 09:35:03', NULL, '2026-09-28 13:16:40');
INSERT INTO `atributos` VALUES ('46', 'equipuo', 'numerico', NULL, '2026-09-11 13:23:52', NULL, '2026-09-28 13:16:38');
INSERT INTO `atributos` VALUES ('47', 'kevin', 'archivo', NULL, '2026-09-14 21:54:54', NULL, '2026-10-19 22:39:11');
INSERT INTO `atributos` VALUES ('48', 'joia', 'texto', NULL, '2026-09-19 15:25:05', NULL, '2026-10-19 22:39:11');
INSERT INTO `atributos` VALUES ('49', 'hola', 'texto', NULL, '2026-09-19 16:02:34', NULL, '2026-10-19 22:39:10');
INSERT INTO `atributos` VALUES ('50', 'gilora', 'numerico', 'mm', '2026-09-28 00:58:27', NULL, '2026-10-19 22:39:09');
INSERT INTO `atributos` VALUES ('51', 'niniyo', 'numerico', 'mm', '2026-09-28 00:59:29', NULL, '2026-10-19 22:39:09');
INSERT INTO `atributos` VALUES ('52', 'bayito', 'numerico', 'mm', '2026-09-28 01:00:00', NULL, '2026-10-19 22:39:08');
INSERT INTO `atributos` VALUES ('53', 'kevinkectuch', 'numerico', 'mm', '2026-09-28 23:30:52', NULL, '2026-10-19 22:39:08');
INSERT INTO `atributos` VALUES ('54', 'php', 'numerico', 'mm', '2026-10-19 22:43:53', NULL, '2026-10-19 22:43:53');
INSERT INTO `atributos` VALUES ('55', 'cantidad paginas', 'numerico', NULL, '2026-10-26 22:30:29', NULL, '2026-10-26 22:30:29');
INSERT INTO `atributos` VALUES ('56', 'garico', 'texto', NULL, '2026-11-16 12:04:53', NULL, '2026-11-16 12:05:03');

DROP TABLE IF EXISTS `auditoria`;
CREATE TABLE `auditoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tabla` enum('objetos','objeto_etiquetas','objeto_atributos','etiquetas','atributos','piezas_imagenes') NOT NULL,
  `accion` enum('a','b','m','r') NOT NULL,
  `id_dato` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `tabla` (`tabla`,`id_dato`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `auditoria_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `auditoria` VALUES ('1', 'objeto_etiquetas', 'a', '46', '3', '2026-11-16 18:48:10');
INSERT INTO `auditoria` VALUES ('2', 'objetos', 'a', '46', '3', '2026-11-16 18:48:10');
INSERT INTO `auditoria` VALUES ('3', 'objetos', 'a', '48', '3', '2026-11-18 20:34:03');

DROP TABLE IF EXISTS `etiquetas`;
CREATE TABLE `etiquetas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `denominacion` varchar(100) NOT NULL,
  `fecha_alta` datetime DEFAULT current_timestamp(),
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_edicion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `etiquetas` VALUES ('1', 'diario', '2026-08-09 00:06:46', NULL, '2026-09-15 23:22:12');
INSERT INTO `etiquetas` VALUES ('3', 'arte romano', '2026-08-11 00:59:30', NULL, '2026-09-15 23:22:38');
INSERT INTO `etiquetas` VALUES ('4', 'colección Vivanco ', '2026-08-11 00:59:56', '2026-09-28 22:35:52', '2026-09-28 22:35:52');
INSERT INTO `etiquetas` VALUES ('5', 'paleontologia', '2026-08-11 14:28:53', '2026-09-28 22:35:48', '2026-09-28 22:35:48');
INSERT INTO `etiquetas` VALUES ('6', 'arte abstracto', '2026-08-11 14:29:30', '2026-09-28 22:35:43', '2026-09-28 22:35:43');
INSERT INTO `etiquetas` VALUES ('7', 'arte romani', '2026-08-11 14:29:57', NULL, '2026-09-28 22:53:10');
INSERT INTO `etiquetas` VALUES ('8', 'arte abstracto', '2026-08-18 12:07:11', NULL, '2026-09-28 22:53:10');
INSERT INTO `etiquetas` VALUES ('9', 'suiza', '2026-09-15 21:51:54', NULL, '2026-09-28 22:53:09');
INSERT INTO `etiquetas` VALUES ('10', 'suizo', '2026-09-15 21:52:07', NULL, '2026-09-28 22:53:08');
INSERT INTO `etiquetas` VALUES ('11', 'altura', '2026-09-17 12:15:19', NULL, '2026-09-28 22:53:07');
INSERT INTO `etiquetas` VALUES ('12', 'luis', '2026-09-17 12:22:52', NULL, '2026-09-28 22:53:07');
INSERT INTO `etiquetas` VALUES ('13', 'cnachunflos', '2026-09-17 12:23:02', NULL, '2026-09-28 22:53:07');
INSERT INTO `etiquetas` VALUES ('14', 'kevin', '2026-09-17 13:43:03', '2026-10-19 22:10:47', '2026-10-19 22:10:47');
INSERT INTO `etiquetas` VALUES ('15', 'firulais', '2026-09-17 21:34:37', '2026-10-19 22:10:44', '2026-10-19 22:10:44');
INSERT INTO `etiquetas` VALUES ('16', 'ferolais', '2026-09-17 21:35:22', '2026-10-19 22:10:40', '2026-10-19 22:10:40');
INSERT INTO `etiquetas` VALUES ('17', 'facebook', '2026-09-17 21:35:57', '2026-09-28 22:53:23', '2026-09-28 22:53:23');
INSERT INTO `etiquetas` VALUES ('18', 'ochotecho', '2026-09-19 16:07:43', '2026-09-28 22:53:19', '2026-09-28 22:53:19');
INSERT INTO `etiquetas` VALUES ('19', 'fefi', '2026-09-19 16:08:13', '2026-09-28 22:53:16', '2026-09-28 22:53:16');
INSERT INTO `etiquetas` VALUES ('20', 'panquesito', '2026-10-19 22:18:27', NULL, '2026-10-19 22:18:27');
INSERT INTO `etiquetas` VALUES ('21', 'panquesito2', '2026-10-19 22:18:53', NULL, '2026-10-19 22:18:53');
INSERT INTO `etiquetas` VALUES ('22', 'libros prohibidos durante la dictadura', '2026-10-26 22:38:54', NULL, '2026-11-11 11:46:29');

DROP TABLE IF EXISTS `museos`;
CREATE TABLE `museos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `denominacion` varchar(100) NOT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `facebook` varchar(150) DEFAULT NULL,
  `instagram` varchar(150) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT current_timestamp(),
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_edicion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `museos` VALUES ('1', 'Museo Histórico Municipal', 'Av. San Martín 123, Victoria, Entre Ríos', '03436-420000', 'contacto@museovictoria.gob.ar', '+5493436123456', 'museohistoricovictoria', '@museovictoria', '2026-06-26 23:22:36', NULL, NULL);

DROP TABLE IF EXISTS `objeto_atributos`;
CREATE TABLE `objeto_atributos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `objeto_id` int(11) DEFAULT NULL,
  `atributo_id` int(11) DEFAULT NULL,
  `valor` varchar(255) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_edicion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_objatr_objeto` (`objeto_id`),
  KEY `fk_objatr_atributo` (`atributo_id`),
  CONSTRAINT `fk_objatr_atributo` FOREIGN KEY (`atributo_id`) REFERENCES `atributos` (`id`),
  CONSTRAINT `fk_objatr_objeto` FOREIGN KEY (`objeto_id`) REFERENCES `objetos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `objeto_atributos` VALUES ('6', '45', '55', '5.4', '2026-10-26 22:42:06', NULL, '2026-10-26 22:42:06');
INSERT INTO `objeto_atributos` VALUES ('7', '45', '10', 'Ex dueño', '2026-10-26 22:42:06', NULL, '2026-10-26 22:42:06');

DROP TABLE IF EXISTS `objeto_etiquetas`;
CREATE TABLE `objeto_etiquetas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `objeto_id` int(11) DEFAULT NULL,
  `etiqueta_id` int(11) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_edicion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_objetq_objeto` (`objeto_id`),
  KEY `fk_objetq_etiqueta` (`etiqueta_id`),
  CONSTRAINT `fk_objetq_etiqueta` FOREIGN KEY (`etiqueta_id`) REFERENCES `etiquetas` (`id`),
  CONSTRAINT `fk_objetq_objeto` FOREIGN KEY (`objeto_id`) REFERENCES `objetos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `objeto_etiquetas` VALUES ('33', '34', '1', '2026-09-28 23:44:52', '2026-10-01 01:19:58', '2026-10-01 01:19:58');
INSERT INTO `objeto_etiquetas` VALUES ('34', '34', '13', '2026-09-28 23:44:52', '2026-10-01 01:19:58', '2026-10-01 01:19:58');
INSERT INTO `objeto_etiquetas` VALUES ('35', '34', '3', '2026-09-28 23:44:52', '2026-10-01 01:19:58', '2026-10-01 01:19:58');
INSERT INTO `objeto_etiquetas` VALUES ('36', '34', '7', '2026-09-28 23:44:52', '2026-10-01 01:19:58', '2026-10-01 01:19:58');
INSERT INTO `objeto_etiquetas` VALUES ('37', '34', '8', '2026-09-28 23:44:52', '2026-10-01 01:19:58', '2026-10-01 01:19:58');
INSERT INTO `objeto_etiquetas` VALUES ('38', '40', '13', '2026-10-01 02:42:28', '2026-10-01 02:52:46', '2026-10-01 02:52:46');
INSERT INTO `objeto_etiquetas` VALUES ('39', '40', '1', '2026-10-01 02:42:28', '2026-10-01 02:52:46', '2026-10-01 02:52:46');
INSERT INTO `objeto_etiquetas` VALUES ('40', '40', '16', '2026-10-01 02:42:28', '2026-10-01 02:52:46', '2026-10-01 02:52:46');
INSERT INTO `objeto_etiquetas` VALUES ('41', '40', '15', '2026-10-01 02:42:28', '2026-10-01 02:52:46', '2026-10-01 02:52:46');
INSERT INTO `objeto_etiquetas` VALUES ('42', '40', '13', '2026-10-01 02:52:46', '2026-10-01 22:15:11', '2026-10-01 22:15:11');
INSERT INTO `objeto_etiquetas` VALUES ('43', '40', '1', '2026-10-01 02:52:46', '2026-10-01 22:15:11', '2026-10-01 22:15:11');
INSERT INTO `objeto_etiquetas` VALUES ('44', '40', '16', '2026-10-01 02:52:46', '2026-10-01 22:15:11', '2026-10-01 22:15:11');
INSERT INTO `objeto_etiquetas` VALUES ('45', '40', '15', '2026-10-01 02:52:46', '2026-10-01 22:15:11', '2026-10-01 22:15:11');
INSERT INTO `objeto_etiquetas` VALUES ('46', '38', '13', '2026-10-01 02:53:02', NULL, '2026-10-01 02:53:02');
INSERT INTO `objeto_etiquetas` VALUES ('47', '38', '1', '2026-10-01 02:53:02', NULL, '2026-10-01 02:53:02');
INSERT INTO `objeto_etiquetas` VALUES ('48', '38', '16', '2026-10-01 02:53:02', NULL, '2026-10-01 02:53:02');
INSERT INTO `objeto_etiquetas` VALUES ('49', '38', '15', '2026-10-01 02:53:02', NULL, '2026-10-01 02:53:02');
INSERT INTO `objeto_etiquetas` VALUES ('50', '38', '14', '2026-10-01 02:53:02', NULL, '2026-10-01 02:53:02');
INSERT INTO `objeto_etiquetas` VALUES ('51', '38', '12', '2026-10-01 02:53:02', NULL, '2026-10-01 02:53:02');
INSERT INTO `objeto_etiquetas` VALUES ('52', '38', '9', '2026-10-01 02:53:02', NULL, '2026-10-01 02:53:02');
INSERT INTO `objeto_etiquetas` VALUES ('53', '39', '16', '2026-10-01 02:53:18', NULL, '2026-10-01 02:53:18');
INSERT INTO `objeto_etiquetas` VALUES ('54', '39', '15', '2026-10-01 02:53:18', NULL, '2026-10-01 02:53:18');
INSERT INTO `objeto_etiquetas` VALUES ('55', '39', '14', '2026-10-01 02:53:18', NULL, '2026-10-01 02:53:18');
INSERT INTO `objeto_etiquetas` VALUES ('56', '39', '12', '2026-10-01 02:53:18', NULL, '2026-10-01 02:53:18');
INSERT INTO `objeto_etiquetas` VALUES ('57', '39', '9', '2026-10-01 02:53:18', NULL, '2026-10-01 02:53:18');
INSERT INTO `objeto_etiquetas` VALUES ('58', '39', '10', '2026-10-01 02:53:18', NULL, '2026-10-01 02:53:18');
INSERT INTO `objeto_etiquetas` VALUES ('59', '36', '16', '2026-10-01 02:54:06', NULL, '2026-10-01 02:54:06');
INSERT INTO `objeto_etiquetas` VALUES ('60', '36', '15', '2026-10-01 02:54:06', NULL, '2026-10-01 02:54:06');
INSERT INTO `objeto_etiquetas` VALUES ('61', '36', '14', '2026-10-01 02:54:06', NULL, '2026-10-01 02:54:06');
INSERT INTO `objeto_etiquetas` VALUES ('62', '36', '12', '2026-10-01 02:54:06', NULL, '2026-10-01 02:54:06');
INSERT INTO `objeto_etiquetas` VALUES ('63', '36', '9', '2026-10-01 02:54:06', NULL, '2026-10-01 02:54:06');
INSERT INTO `objeto_etiquetas` VALUES ('64', '36', '10', '2026-10-01 02:54:06', NULL, '2026-10-01 02:54:06');
INSERT INTO `objeto_etiquetas` VALUES ('65', '40', '13', '2026-10-01 22:15:11', NULL, '2026-10-01 22:15:11');
INSERT INTO `objeto_etiquetas` VALUES ('66', '40', '1', '2026-10-01 22:15:11', NULL, '2026-10-01 22:15:11');
INSERT INTO `objeto_etiquetas` VALUES ('67', '40', '16', '2026-10-01 22:15:11', NULL, '2026-10-01 22:15:11');
INSERT INTO `objeto_etiquetas` VALUES ('68', '40', '15', '2026-10-01 22:15:11', NULL, '2026-10-01 22:15:11');
INSERT INTO `objeto_etiquetas` VALUES ('69', '42', '13', '2026-10-02 13:11:03', NULL, '2026-10-02 13:11:03');
INSERT INTO `objeto_etiquetas` VALUES ('70', '42', '1', '2026-10-02 13:11:03', NULL, '2026-10-02 13:11:03');
INSERT INTO `objeto_etiquetas` VALUES ('71', '42', '16', '2026-10-02 13:11:03', NULL, '2026-10-02 13:11:03');
INSERT INTO `objeto_etiquetas` VALUES ('72', '42', '15', '2026-10-02 13:11:03', NULL, '2026-10-02 13:11:03');
INSERT INTO `objeto_etiquetas` VALUES ('73', '42', '14', '2026-10-02 13:11:03', NULL, '2026-10-02 13:11:03');
INSERT INTO `objeto_etiquetas` VALUES ('74', '42', '12', '2026-10-02 13:11:03', NULL, '2026-10-02 13:11:03');
INSERT INTO `objeto_etiquetas` VALUES ('75', '42', '9', '2026-10-02 13:11:03', NULL, '2026-10-02 13:11:03');
INSERT INTO `objeto_etiquetas` VALUES ('76', '43', '7', '2026-10-12 02:23:23', '2026-10-13 13:04:20', '2026-10-13 13:04:20');
INSERT INTO `objeto_etiquetas` VALUES ('77', '43', '3', '2026-10-12 02:23:23', '2026-10-13 13:04:20', '2026-10-13 13:04:20');
INSERT INTO `objeto_etiquetas` VALUES ('78', '43', '13', '2026-10-12 02:23:23', '2026-10-13 13:04:20', '2026-10-13 13:04:20');
INSERT INTO `objeto_etiquetas` VALUES ('79', '43', '1', '2026-10-12 02:23:23', '2026-10-13 13:04:20', '2026-10-13 13:04:20');
INSERT INTO `objeto_etiquetas` VALUES ('80', '43', '16', '2026-10-12 02:23:23', '2026-10-13 13:04:20', '2026-10-13 13:04:20');
INSERT INTO `objeto_etiquetas` VALUES ('81', '43', '15', '2026-10-12 02:23:23', '2026-10-13 13:04:20', '2026-10-13 13:04:20');
INSERT INTO `objeto_etiquetas` VALUES ('82', '43', '14', '2026-10-12 02:23:23', '2026-10-13 13:04:20', '2026-10-13 13:04:20');
INSERT INTO `objeto_etiquetas` VALUES ('83', '43', '12', '2026-10-12 02:23:23', '2026-10-13 13:04:20', '2026-10-13 13:04:20');
INSERT INTO `objeto_etiquetas` VALUES ('84', '43', '9', '2026-10-12 02:23:23', '2026-10-13 13:04:20', '2026-10-13 13:04:20');
INSERT INTO `objeto_etiquetas` VALUES ('85', '43', '10', '2026-10-12 02:23:23', '2026-10-13 13:04:20', '2026-10-13 13:04:20');
INSERT INTO `objeto_etiquetas` VALUES ('86', '43', '7', '2026-10-13 13:04:20', '2026-10-13 13:04:40', '2026-10-13 13:04:40');
INSERT INTO `objeto_etiquetas` VALUES ('87', '43', '3', '2026-10-13 13:04:20', '2026-10-13 13:04:40', '2026-10-13 13:04:40');
INSERT INTO `objeto_etiquetas` VALUES ('88', '43', '13', '2026-10-13 13:04:20', '2026-10-13 13:04:40', '2026-10-13 13:04:40');
INSERT INTO `objeto_etiquetas` VALUES ('89', '43', '1', '2026-10-13 13:04:20', '2026-10-13 13:04:40', '2026-10-13 13:04:40');
INSERT INTO `objeto_etiquetas` VALUES ('90', '43', '16', '2026-10-13 13:04:20', '2026-10-13 13:04:40', '2026-10-13 13:04:40');
INSERT INTO `objeto_etiquetas` VALUES ('91', '43', '15', '2026-10-13 13:04:20', '2026-10-13 13:04:40', '2026-10-13 13:04:40');
INSERT INTO `objeto_etiquetas` VALUES ('92', '43', '14', '2026-10-13 13:04:20', '2026-10-13 13:04:40', '2026-10-13 13:04:40');
INSERT INTO `objeto_etiquetas` VALUES ('93', '43', '12', '2026-10-13 13:04:20', '2026-10-13 13:04:40', '2026-10-13 13:04:40');
INSERT INTO `objeto_etiquetas` VALUES ('94', '43', '9', '2026-10-13 13:04:20', '2026-10-13 13:04:40', '2026-10-13 13:04:40');
INSERT INTO `objeto_etiquetas` VALUES ('95', '43', '10', '2026-10-13 13:04:20', '2026-10-13 13:04:40', '2026-10-13 13:04:40');
INSERT INTO `objeto_etiquetas` VALUES ('96', '43', '7', '2026-10-13 13:04:40', '2026-10-13 13:09:19', '2026-10-13 13:09:19');
INSERT INTO `objeto_etiquetas` VALUES ('97', '43', '3', '2026-10-13 13:04:40', '2026-10-13 13:09:19', '2026-10-13 13:09:19');
INSERT INTO `objeto_etiquetas` VALUES ('98', '43', '13', '2026-10-13 13:04:40', '2026-10-13 13:09:19', '2026-10-13 13:09:19');
INSERT INTO `objeto_etiquetas` VALUES ('99', '43', '1', '2026-10-13 13:04:40', '2026-10-13 13:09:19', '2026-10-13 13:09:19');
INSERT INTO `objeto_etiquetas` VALUES ('100', '43', '16', '2026-10-13 13:04:40', '2026-10-13 13:09:19', '2026-10-13 13:09:19');
INSERT INTO `objeto_etiquetas` VALUES ('101', '43', '15', '2026-10-13 13:04:40', '2026-10-13 13:09:19', '2026-10-13 13:09:19');
INSERT INTO `objeto_etiquetas` VALUES ('102', '43', '14', '2026-10-13 13:04:40', '2026-10-13 13:09:19', '2026-10-13 13:09:19');
INSERT INTO `objeto_etiquetas` VALUES ('103', '43', '12', '2026-10-13 13:04:40', '2026-10-13 13:09:19', '2026-10-13 13:09:19');
INSERT INTO `objeto_etiquetas` VALUES ('104', '43', '9', '2026-10-13 13:04:40', '2026-10-13 13:09:19', '2026-10-13 13:09:19');
INSERT INTO `objeto_etiquetas` VALUES ('105', '43', '10', '2026-10-13 13:04:40', '2026-10-13 13:09:19', '2026-10-13 13:09:19');
INSERT INTO `objeto_etiquetas` VALUES ('106', '43', '1', '2026-10-13 13:09:19', '2026-10-13 13:13:22', '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('107', '43', '3', '2026-10-13 13:09:19', '2026-10-13 13:13:22', '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('108', '43', '7', '2026-10-13 13:09:19', '2026-10-13 13:13:22', '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('109', '43', '9', '2026-10-13 13:09:19', '2026-10-13 13:13:22', '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('110', '43', '10', '2026-10-13 13:09:19', '2026-10-13 13:13:22', '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('111', '43', '12', '2026-10-13 13:09:19', '2026-10-13 13:13:22', '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('112', '43', '13', '2026-10-13 13:09:19', '2026-10-13 13:13:22', '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('113', '43', '14', '2026-10-13 13:09:19', '2026-10-13 13:13:22', '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('114', '43', '15', '2026-10-13 13:09:19', '2026-10-13 13:13:22', '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('115', '43', '16', '2026-10-13 13:09:19', '2026-10-13 13:13:22', '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('116', '43', '1', '2026-10-13 13:13:22', NULL, '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('117', '43', '3', '2026-10-13 13:13:22', NULL, '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('118', '43', '7', '2026-10-13 13:13:22', NULL, '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('119', '43', '9', '2026-10-13 13:13:22', NULL, '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('120', '43', '10', '2026-10-13 13:13:22', NULL, '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('121', '43', '12', '2026-10-13 13:13:22', NULL, '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('122', '43', '13', '2026-10-13 13:13:22', NULL, '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('123', '43', '14', '2026-10-13 13:13:22', NULL, '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('124', '43', '15', '2026-10-13 13:13:22', NULL, '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('125', '43', '16', '2026-10-13 13:13:22', NULL, '2026-10-13 13:13:22');
INSERT INTO `objeto_etiquetas` VALUES ('126', '45', '22', '2026-10-26 22:42:06', NULL, '2026-10-26 22:42:06');
INSERT INTO `objeto_etiquetas` VALUES ('127', '46', '13', '2026-11-16 21:48:10', NULL, '2026-11-16 21:48:10');
INSERT INTO `objeto_etiquetas` VALUES ('128', '46', '1', '2026-11-16 21:48:10', NULL, '2026-11-16 21:48:10');
INSERT INTO `objeto_etiquetas` VALUES ('129', '46', '22', '2026-11-16 21:48:10', NULL, '2026-11-16 21:48:10');
INSERT INTO `objeto_etiquetas` VALUES ('130', '46', '12', '2026-11-16 21:48:10', NULL, '2026-11-16 21:48:10');
INSERT INTO `objeto_etiquetas` VALUES ('131', '46', '20', '2026-11-16 21:48:10', NULL, '2026-11-16 21:48:10');

DROP TABLE IF EXISTS `objetos`;
CREATE TABLE `objetos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(50) DEFAULT NULL,
  `denominacion` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT current_timestamp(),
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_edicion` datetime DEFAULT NULL,
  `id_ubicacion` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_usuario` (`id_usuario`),
  KEY `fk_objetos_ubicacion` (`id_ubicacion`),
  CONSTRAINT `fk_objetos_ubicacion` FOREIGN KEY (`id_ubicacion`) REFERENCES `salas` (`id`),
  CONSTRAINT `fk_objetos_usuarios` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `objetos` VALUES ('33', 'AQ87', 'sebas', 'sebas era un gran pintor', '3', '2026-09-28 23:44:52', NULL, '2026-11-18 13:09:38', NULL);
INSERT INTO `objetos` VALUES ('34', 'AQ87', 'sebas', 'sebas era un gran pintor', '3', '2026-09-28 23:44:52', NULL, '2026-11-18 13:09:39', NULL);
INSERT INTO `objetos` VALUES ('35', 'ABJ', 'nino', 'Nino era un gato muy guapo y de carton', '3', '2026-09-30 23:53:38', NULL, '2026-11-18 13:08:44', '12');
INSERT INTO `objetos` VALUES ('36', '12312312', 'kevin', '', '3', '2026-09-30 23:54:34', NULL, '2026-11-18 13:04:55', '11');
INSERT INTO `objetos` VALUES ('37', 'k34', 'mkultra', 'Proyecto mk ultra', '23', '2026-10-01 00:10:51', NULL, '2026-11-18 13:08:56', '12');
INSERT INTO `objetos` VALUES ('38', 'HK34', 'felfor', '', '23', '2026-10-01 01:45:52', '2026-10-19 22:37:12', '2026-10-19 22:37:12', NULL);
INSERT INTO `objetos` VALUES ('39', 'ABG12', 'alfa romero', 'romero', '23', '2026-10-01 02:28:57', '2026-10-19 22:36:41', '2026-10-19 22:36:41', NULL);
INSERT INTO `objetos` VALUES ('40', 'kas', 'alfa ro', 'dsasd', '23', '2026-10-01 02:42:28', '2026-10-19 22:36:37', '2026-10-19 22:36:37', NULL);
INSERT INTO `objetos` VALUES ('41', 'A4325', 'guarda pelo', 'guarda pelo de rowina reibenclau', '3', '2026-10-02 13:07:44', '2026-10-19 22:36:35', '2026-10-19 22:36:35', NULL);
INSERT INTO `objetos` VALUES ('42', 'A4325', 'ak-47', 'AK-47 perteneciente a tp2 pack', '3', '2026-10-02 13:11:03', '2026-10-19 22:36:34', '2026-10-19 22:36:34', NULL);
INSERT INTO `objetos` VALUES ('43', 'kas', 'juanpasurita', 'Examen extra opcional', '13', '2026-10-12 02:23:23', '2026-10-19 22:36:31', '2026-10-19 22:36:31', NULL);
INSERT INTO `objetos` VALUES ('44', 'gyuy', 'tyruytu', 'hhttr', '3', '2026-10-19 22:34:12', '2026-10-19 22:36:28', '2026-10-19 22:36:28', NULL);
INSERT INTO `objetos` VALUES ('45', 'Ab11', 'rebelión en la granja', 'Ejemplar de libro rebelión en la granja', '3', '2026-10-26 22:42:06', NULL, '2026-11-18 13:08:50', '12');
INSERT INTO `objetos` VALUES ('46', 'A4325', 'jarron shin', '', '3', '2026-11-16 21:48:10', NULL, '2026-11-18 13:05:01', '11');
INSERT INTO `objetos` VALUES ('47', 'A4325', 'gato', 'gato', '3', '2026-11-18 22:42:00', NULL, '2026-11-18 22:42:00', NULL);
INSERT INTO `objetos` VALUES ('48', 'dasadds', 'dasdas', 'sadas', '3', '2026-11-18 23:34:03', NULL, '2026-11-18 23:34:03', NULL);

DROP TABLE IF EXISTS `piezas_archivos`;
CREATE TABLE `piezas_archivos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `objeto_id` int(11) NOT NULL,
  `nombrearchivo` varchar(255) NOT NULL,
  `nombreoriginal` varchar(255) NOT NULL,
  `fecha_alta` datetime DEFAULT current_timestamp(),
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_edicion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_parch_objeto` (`objeto_id`),
  CONSTRAINT `fk_parch_objeto` FOREIGN KEY (`objeto_id`) REFERENCES `objetos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


DROP TABLE IF EXISTS `piezas_imagenes`;
CREATE TABLE `piezas_imagenes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `objeto_id` int(11) NOT NULL,
  `nombrearchivo` varchar(255) NOT NULL,
  `portada` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_alta` datetime DEFAULT current_timestamp(),
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_edicion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_pimg_objeto` (`objeto_id`),
  CONSTRAINT `fk_pimg_objeto` FOREIGN KEY (`objeto_id`) REFERENCES `objetos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `piezas_imagenes` VALUES ('1', '48', '48_20261118233403_Captura_de_pantalla_2026-08-02_12-38-21.png', '1', '2026-11-18 23:34:03', NULL, '2026-11-18 23:34:03');

DROP TABLE IF EXISTS `rol_permiso`;
CREATE TABLE `rol_permiso` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_rol` int(10) unsigned NOT NULL,
  `objeto` set('a','b','m','l') NOT NULL,
  `etiqueta` set('a','b','m','l') NOT NULL,
  `atributo` set('a','b','m','l') NOT NULL,
  `usuario` set('a','b','m','l') NOT NULL,
  `sala` set('a','b','m','l') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_rol` (`id_rol`),
  CONSTRAINT `rol_permiso_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `rol_permiso` VALUES ('1', '1', 'a,b,m,l', 'a,b,m,l', 'a,b,m,l', 'a,b,m,l', 'a,b,m,l');
INSERT INTO `rol_permiso` VALUES ('2', '2', 'a,m,l', 'l', 'l', '', 'a,m,l');
INSERT INTO `rol_permiso` VALUES ('3', '3', 'l', '', '', '', 'l');
INSERT INTO `rol_permiso` VALUES ('4', '4', 'a,b,m,l', 'a,b,m,l', 'a,b,m,l', 'l', 'a,b,m,l');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `denominacion` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_denominacion` (`denominacion`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` VALUES ('1', 'administrador');
INSERT INTO `roles` VALUES ('4', 'gerente');
INSERT INTO `roles` VALUES ('3', 'invitado');
INSERT INTO `roles` VALUES ('2', 'operador');

DROP TABLE IF EXISTS `salas`;
CREATE TABLE `salas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `denominacion` varchar(100) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `id_pertenece` int(10) unsigned DEFAULT NULL,
  `fecha_alta` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_edicion` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_salas_pertenece` (`id_pertenece`),
  CONSTRAINT `fk_salas_pertenece` FOREIGN KEY (`id_pertenece`) REFERENCES `salas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `salas` VALUES ('1', 'museo', NULL, NULL, '2026-11-01 21:57:45', NULL, NULL);
INSERT INTO `salas` VALUES ('4', 'Deposito', 'Deposito, ubicado al final del museo', '1', '2026-11-06 12:03:35', '2026-11-13 23:07:14', '2026-11-13 23:07:14');
INSERT INTO `salas` VALUES ('6', 'Mueble B', 'Mueble B con revistas viejas', '4', '2026-11-06 22:10:01', '2026-11-13 23:07:07', '2026-11-13 23:07:07');
INSERT INTO `salas` VALUES ('7', 'Estante B.1', 'Estante B.1', '6', '2026-11-06 22:11:30', '2026-11-13 23:06:59', '2026-11-13 23:06:59');
INSERT INTO `salas` VALUES ('8', 'juanp', '', '1', '2026-11-13 02:15:36', '2026-11-13 23:07:38', '2026-11-13 23:07:38');
INSERT INTO `salas` VALUES ('9', 'luis', '', '8', '2026-11-13 02:15:54', '2026-11-13 23:07:34', '2026-11-13 23:07:34');
INSERT INTO `salas` VALUES ('10', 'juanpasurita', '', '9', '2026-11-13 02:16:03', '2026-11-13 23:07:29', '2026-11-13 23:07:29');
INSERT INTO `salas` VALUES ('11', 'sala 2', '', '1', '2026-11-18 12:45:21', NULL, '2026-11-18 12:45:21');
INSERT INTO `salas` VALUES ('12', 'mueble c', '', '11', '2026-11-18 13:08:33', NULL, '2026-11-18 13:08:33');
INSERT INTO `salas` VALUES ('13', 'caja b', '', '12', '2026-11-18 13:09:06', NULL, '2026-11-18 13:09:06');

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `denominacion` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `fecha_alta` datetime DEFAULT current_timestamp(),
  `fecha_baja` datetime DEFAULT NULL,
  `fecha_edicion` datetime DEFAULT NULL,
  `id_rol` int(10) unsigned NOT NULL DEFAULT 3,
  PRIMARY KEY (`id`),
  KEY `idx_usuarios_id_rol` (`id_rol`),
  CONSTRAINT `fk_usuarios_rol` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `usuarios` VALUES ('1', 'altura', 'luis@gmail.com', '', '5374621872', '2026-08-18 13:27:05', NULL, '2026-10-12 02:05:28', '3');
INSERT INTO `usuarios` VALUES ('2', 'luis2', 'luis@gmail.com', '', '12343523', '2026-08-18 13:28:12', NULL, '2026-08-18 13:28:12', '3');
INSERT INTO `usuarios` VALUES ('3', 'juanp', 'juanp@gmail.com', '$2y$10$M41nY0xKUmuNWlo3QRVMP.7yidKrU2YbyOmJc6CJ475Fgl9i/fUqu', '625735218', '2026-08-18 13:56:57', NULL, '2026-11-19 00:09:31', '1');
INSERT INTO `usuarios` VALUES ('4', 'gj', 'gj@gmail.com', '$2y$10$g8O6E3WJvySECLlFvjzzwuHY9ZWkjZDGBLqcwrisIFpJdk.8Q4Geu', '26384281', '2026-08-21 21:42:00', NULL, '2026-08-21 21:42:00', '3');
INSERT INTO `usuarios` VALUES ('5', 'juanv', 'pedro@gmail.com', '$2y$10$7P/Ap3TDvNx4snu0yD4JA.MhplUVH0p1WYm/Uz15vWsD6R34FKjcS', '123443123412', '2026-08-21 21:45:22', NULL, '2026-08-22 00:07:51', '3');
INSERT INTO `usuarios` VALUES ('6', 'sadsad', 'jsjdjsjd@gmail.com', '$2y$10$ZcdmzYcOUtIi3qvbBPQ19OLB.VXlLjeb3j.RC1Y7tB6gIVqRHbUBG', '123721837621', '2026-08-21 21:49:32', NULL, '2026-08-21 23:47:20', '3');
INSERT INTO `usuarios` VALUES ('7', 'julio', 'julia@gmail.com', '$2y$10$ExIqOqZHmbSl/EVpa19K9.wzZx3X9PiyWaZaucdzvCxWBMCHNPd32', '', '2026-08-21 21:58:26', NULL, '2026-08-21 21:58:26', '3');
INSERT INTO `usuarios` VALUES ('8', 'julianos', 'julianos@gmail.com', '$2y$10$SR.21WNDlE.0HL58weveIeLjFwl2Ogmw6Y4.EnUUD8wts8nHQr/pu', '12343242', '2026-08-21 23:56:55', NULL, '2026-08-21 23:56:55', '3');
INSERT INTO `usuarios` VALUES ('9', 'juli', 'juli@gmail.com', '$2y$10$E5seaW4uvKJO.eT4lSAFNuQ01dtATs69YPMyrD453Uidy6DEpYpDW', '1231231', '2026-08-21 23:58:21', NULL, '2026-10-12 02:05:27', '3');
INSERT INTO `usuarios` VALUES ('10', 'godines', 'godines@gmail.com', '$2y$10$hxxePdz3y4IAjO39QPmw/.jv3V2soLIX8tzJ6pyI5uqXsmFZUX0be', '387671278321', '2026-08-24 13:58:00', NULL, '2026-10-12 02:05:26', '3');
INSERT INTO `usuarios` VALUES ('11', 'godines2', 'godines2@gmail.com', '$2y$10$DM35kNDBGjKnYRr/Qi4ycO/9Zay7GrSghEYYJhmTriVs/ZFdh6ENy', '86876872123', '2026-08-24 13:58:33', NULL, '2026-10-12 02:05:25', '3');
INSERT INTO `usuarios` VALUES ('12', 'pericles', 'pericles@gmail.com', '$2y$10$oHoJecP3DrF.ptpBe5tLSOz7t8sGArswjcsC4jfE.UYJ//2EEAYde', '1237126312', '2026-08-24 14:01:59', NULL, '2026-09-28 21:44:12', '3');
INSERT INTO `usuarios` VALUES ('13', 'pepe', 'pepealiaspollo@gmail.com', '$2y$10$WmxGCxiFQPLtM43jGWrBaO7GRbbgpZl6yP6bfO3g6fn0OqnZEUJ/i', '889261938192836', '2026-08-24 14:24:54', NULL, '2026-10-12 02:15:16', '2');
INSERT INTO `usuarios` VALUES ('14', 'lushi', 'lushi@gmail.com', '$2y$10$bj4mf5Rjd2BthSzk.Tndv.etjoIM/o3pYGlR5KeF3Q6fw/SKR9gO6', '98912837123', '2026-08-24 14:25:54', NULL, '2026-09-28 11:22:42', '3');
INSERT INTO `usuarios` VALUES ('15', 'jk', 'jk@gmail.com', '$2y$10$V/sPCpEiGbBypCtNPsAWTuhdi6JwEGvS5Li4Q78hjDq8KJfEurT6m', '21312321', '2026-08-24 14:27:08', NULL, '2026-09-28 21:44:09', '3');
INSERT INTO `usuarios` VALUES ('16', 'kevin', 'luis@gmail.com', '$2y$10$ZDdW0QTFYZGCYcN9dmi8G.xT5lPOia3SdVVP71SKZzTQB.6W2TX1a', '213123123', '2026-08-24 23:03:28', NULL, '2026-09-28 21:44:08', '3');
INSERT INTO `usuarios` VALUES ('17', 'joaquin', 'jkking@gmail.com', '$2y$10$UNZkSuJvat6wlyZ44iWWOeY/zD5iRE8YrcRBLH.cttP3yFoHmP762', '210930129039129', '2026-09-21 17:02:24', NULL, '2026-09-28 21:44:08', '3');
INSERT INTO `usuarios` VALUES ('18', 'joaquina', 'jkking@gmail.com', '$2y$10$7v71sPAq2qRNabClWcAOyOiJwWIhACfhzNipFI.GTLH6q3HsyKL3G', '210930129039129', '2026-09-21 22:38:32', NULL, '2026-09-28 21:44:07', '3');
INSERT INTO `usuarios` VALUES ('19', 'nati', 'juli@gmail.com', '$2y$10$snf6Qi9xqBv4zgmXh3nAmenWSP5IajEPu9mjyT5FSlQAf6DJby6iu', '1231231', '2026-09-21 22:51:55', NULL, '2026-09-28 21:44:05', '3');
INSERT INTO `usuarios` VALUES ('20', 'nicolas', 'pericles@gmail.com', '$2y$10$3T95VNPENKyx55Bb2lK8kOhcpaGKBMvG7s3pMGnKeJOadPudRBJBS', '1237126312', '2026-09-21 22:53:55', NULL, '2026-09-28 21:44:04', '3');
INSERT INTO `usuarios` VALUES ('21', 'jaimes', 'jaimes@gmail.com', '$2y$10$.ftF6leCDMGwGDooeBhOBu9ZuAwoycnzaZY3ohPF7ZcNB2Yt9wTIa', '987219839183', '2026-09-25 11:55:51', NULL, '2026-09-28 21:44:03', '3');
INSERT INTO `usuarios` VALUES ('22', 'lolipop', 'lolipop@gmail.com', '$2y$10$QAlIUX.xQ0Znlnwb1DzrMeVgAlzAqc/xuiHWiNifBBXl/myL2uR.6', '899273981723', '2026-09-28 12:30:08', NULL, '2026-10-12 01:41:29', '4');
INSERT INTO `usuarios` VALUES ('23', 'lola', 'lolabony@gmail.com', '$2y$10$UBA9DkxJGv0kXBpYM4kW4uWnLhZj.Uy6PQPGKqlWmDir75Sx5j0IC', '432423134', '2026-10-01 00:09:54', NULL, '2026-10-13 13:17:43', '4');
INSERT INTO `usuarios` VALUES ('24', 'edgardolui', 'lui@gmail.com', '$2y$10$nZpKeZR0szbz31BLfsG18.wNX1AyIqTW1z3jemP3hBsQtqQZIAEMC', '123213123', '2026-10-07 02:18:36', NULL, '2026-10-17 17:48:51', '3');
INSERT INTO `usuarios` VALUES ('25', 'eleuteria', 'eleu@gmail.com', '$2y$10$j20qmxSLejqtWDe.FBiU1u6kYk4Aq.M0ZnKucCB.VYvABqgchSNdS', '123123123', '2026-10-13 11:44:57', NULL, '2026-11-19 00:13:32', '3');
INSERT INTO `usuarios` VALUES ('26', 'loresmas', 'loresmas@gmail.com', '$2y$10$VsNyhNJfEGoqUXhslAPa4.64kVjm/LlFEDdsODci.UhhumDyfBUjK', '2392109830192', '2026-10-17 17:51:19', '2026-10-26 22:18:46', '2026-10-26 22:18:46', '1');
INSERT INTO `usuarios` VALUES ('27', 'cumbia420', 'cumbia420@gmail.com', '$2y$10$DhWFL8ub2v7dzIHeDmFw.uLwHU1HJ44UmWzSg4X0c5LeL0Ml4GWR6', '9821793812793', '2026-10-19 22:29:24', '2026-10-19 22:31:04', '2026-10-19 22:31:04', '1');
INSERT INTO `usuarios` VALUES ('28', 'josesito', 'jose@gmail.com', '$2y$10$pKjioh5ITTKbqrL15uP.f.xmkpp1E5CqfHMqW.w1G1pBmXRMFhSZ2', '123123123123', '2026-11-13 11:59:52', NULL, '2026-11-13 11:59:52', '1');
INSERT INTO `usuarios` VALUES ('29', 'etor maina', 'etor@gmail.com', '$2y$10$FMAxp7T0WKn6TiTxzLCOeui0/UMhcSk3G7R7cZHG22C/GaETfz7ay', '21321312', '2026-11-16 11:51:32', NULL, '2026-11-16 11:51:32', '3');
INSERT INTO `usuarios` VALUES ('30', 'maxi', 'maximiliano@gmail.com', '$2y$10$5a9fyZlr72caiqAzQBCDquvjvkMEMBglILyAsF.C0Au2tuJhzMqai', '2312132121', '2026-11-16 21:35:31', NULL, '2026-11-16 21:35:31', '4');

